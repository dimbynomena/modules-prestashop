jQuery(window).resize(function() {
	jQuery( ".manager-text" ).css( "top", jQuery( '.block-header' ).height());
});