<?php 
if(!defined('_PS_VERSION_')) {
    exit();
}

class Gestionfraisdeport extends Module {

    public function __construct() {
        $this->name = 'gestionfraisdeport';
        $this->version = '1.0.0';
        $this->author = 'KiweeRouge';
        $this->tab = 'administration';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Gestion des frais de port');
        $this->description = $this->l('Gestion des frais de port');
        $this->confirmUninstall = $this->l('Are you sure to uninstall?');
    }

    public function install() {
        return parent::install() && $this->registerHook('displayHeader');
    }

    public function uninstall() {
        return $this->unregisterHook('displayHeader') && parent::uninstall();
    }

    public static function getCarriers($cart, $country = null) {
        $delivery_option_list = $cart->getDeliveryOptionList($country, true);
        $carriers = array();
        if (count($delivery_option_list) > 1 || empty($delivery_option_list)) {
            return $carriers;
        }
        foreach (reset($delivery_option_list) as $key => $option) {
            foreach ($option['carrier_list'] as $id_carrier => $carrier) {
                if (isset($carrier['instance'])) {
                    $name = $carrier['instance']->name;
                    $delay = $carrier['instance']->delay;
                    $delay = isset($delay[Context::getContext()->language->id]) ?
                    $delay[Context::getContext()->language->id] :
                    $delay[(int) Configuration::get('PS_LANG_DEFAULT')];
                }
                if (isset($carrier['logo'])) {
                    $img = $carrier['logo'];
                }
                $carriers[] = array(
                    'name' => $name,
                    'img' => $img,
                    'delay' => $delay,
                    'product_list' => (isset($carrier['product_list']) ? $carrier['product_list'] : null),
                    'id_carrier' => Cart::intifier($id_carrier),
                    'is_module' => false
                );
            }
        }
        return $carriers;
    }

    public function getCountryDefault($cart)
    {
        $id_country = null;
        if (isset($cart->id_address_delivery) && (int) $cart->id_address_delivery) {
            $add_delivery = new Address($cart->id_address_delivery);
            $id_country = (int) $add_delivery->id_country;
        } else {
            if (isset($this->context->cookie->id_country) && $this->context->cookie->id_country > 0) {
                $id_country = (int) $this->context->cookie->id_country;
            }
        }
        if (!isset($id_country)) {
            $id_country = (
                isset($this->context->customer->geoloc_id_country) ?
                (int) $this->context->customer->geoloc_id_country :
                (int) Configuration::get('PS_COUNTRY_DEFAULT')
                );
        }
        return $id_country;
    }

    private function initializeAddress($cart, $id_country = null)
    {
        $address = new Address();
        $with_geoloc = true;
        if (isset($id_country) && (int) $id_country) {
            $address->id_country = (isset($id_country) ? (int) $id_country : (int) Context::getContext()->country->id);
            $address->id_state = 0;
            $address->postcode = 0;
        } else {
            if (Configuration::get('PS_TAX_ADDRESS_TYPE') == 'id_address_invoice') {
                $id_address = (int) $cart->id_address_invoice;
            } else {
                $id_address = null;
            }
            if (!Address::addressExists($id_address)) {
                $id_address = null;
            }
            if ($id_address) {
                $address = new Address((int) $id_address);
                if (!Validate::isLoadedObject($address)) {
                    throw new PrestaShopException('Invalid address #'.(int) $id_address);
                }
            } elseif ($with_geoloc && isset($this->context->customer->geoloc_id_country)) {
                $address->id_country = (int) $this->context->customer->geoloc_id_country;
                $address->id_state = (int) $this->context->customer->id_state;
                $address->zipcode = $this->context->customer->postcode;
            } else {
                $address = new Address();
                $address->id_country = (int) $this->context->country->id;
                $address->id_state = 0;
                $address->postcode = 0;
            }
        }
        return $address;
    }

    /*
     * * Get carriers by country id, called by the ajax process
     */
    public function getCarriersListByIdZone($id_country, $id_state = 0, $zipcode = 0, $city = '')
    {
        // cookie saving/updating
        $this->context->cookie->id_country = $id_country;
        if ($id_state != 0) {
            $this->context->cookie->id_state = $id_state;
        }
        if ($zipcode != 0) {
            $this->context->cookie->postcode = $zipcode;
        }
        if (!empty($city)) {
            $this->context->cookie->city = $city;
        }
        $id_zone = 0;
        if ($id_state != 0) {
            $id_zone = State::getIdZone($id_state);
        }
        if (!$id_zone) {
            $id_zone = Country::getIdZone($id_country);
        }
        $carriers = self::getCarriersByCountry(
            $id_country,
            $id_state,
            $zipcode,
            $city,
            $this->context->cart,
            $this->context->customer->id
        );
        return (count($carriers) ? $carriers : array());
    }

    /*
     * Get all carriers available for this zon
     */
    public static function getCarriersByCountry($id_country, $id_state, $zipcode, $city, $exiting_cart, $id_customer)
    {
        // Create temporary Address
        $addr_temp = new Address();
        $addr_temp->id_customer = $id_customer;
        $addr_temp->id_country = $id_country;
        $addr_temp->id_state = $id_state;
        if (empty($zipcode)) {
            $zipcode = '0';
        }
        $addr_temp->postcode = $zipcode;
        if (empty($city)) {
            $city = '.';
        }
        $addr_temp->city = $city;
        // Populate required attributes
        // Note: Some carrier needs the whole address
        // the '.' will do the job
        $addr_temp->company = '.';
        $addr_temp->firstname = '.';
        $addr_temp->phone ='.';
        $addr_temp->phone_mobile ='.';
        $addr_temp->lastname = '.';
        $addr_temp->address1 = '.';
        $addr_temp->address2 = '.';
        $addr_temp->vat_number = '.';
        $addr_temp->dni = '.';
        $addr_temp->alias = 'TEMPORARY_ADDRESS_TO_DELETE';
        $addr_temp->save();
        $cart_temp = new Cart();
        $cart_temp->id_currency = $exiting_cart->id_currency;
        $cart_temp->id_customer = $exiting_cart->id_customer;
        $cart_temp->id_lang = $exiting_cart->id_lang;
        $cart_temp->id_address_delivery = $addr_temp->id;
        $cart_temp->add();
        $products = $exiting_cart->getProducts();
        foreach ($products as $key => $product) {
            $cart_temp->updateQty($product['quantity'], $product['id_product'], $product['id_product_attribute']);
        }
        $update_cart_context = false;
        // Some carrier module work with context->cart, so work with fictive cart is not recommended(eg : envoimoincher)
        if (isset($exiting_cart) && !(int) $exiting_cart->id_address_delivery && (int) $addr_temp->id) {
            $exiting_cart->id_address_delivery = $addr_temp->id;
            $update_cart_context = true;
        }
        $carriers = self::getCarriers($cart_temp);
        if ($update_cart_context) {
            $exiting_cart->id_address_delivery = 0;
        }
        $key = 'address_exists_'.(int)$addr_temp->id;
        Cache::store($key, false);
        // delete temporary objects
        $addr_temp->delete();
        $cart_temp->delete();
        return $carriers;
    }

    public function hookDisplayHeader($params) {    
        global $cookie;
        /* Add CSS and JS */
        $this->context->controller->addCSS(($this->_path).'views/css/gestionfraisdeportstyle.css', 'all');
        $this->context->controller->addJS(($this->_path).'views/js/gestionfraisdeport.js');

        $pricelimit = (float) Configuration::get('PS_GESTION_PORT');
        $cart = $this->context->cart;
        $id_country = $this->getCountryDefault($cart);
        $address = new Address($cart->id_address_delivery);
        $id_state = $address->id_state;
        $zipcode = $address->postcode;
        $city = $address->city;
        if($cookie->isLogged())
        {
            if (isset($id_country) && (int) $id_country > 0) {
                $address_inv = $this->initializeAddress($cart, $id_country);
                $country = new Country($id_country, (int) $this->context->cookie->id_lang);
                $simulate_addr = true;
                if ((int) $cart->id_address_delivery) {
                    if (((int) $address->id_country == (int) $id_country)
                        && (Tools::strtoupper($address->postcode) == Tools::strtoupper($zipcode))
                        && (Tools::strtoupper($address->city) == Tools::strtoupper($city))) {
                        $simulate_addr = false;
                        $carriers = self::getCarriers($cart);
                    }
                }

                if ($simulate_addr) {
                    $carriers = $this->getCarriersListByIdZone($id_country, $id_state, $zipcode, $city);
                }
                
                foreach ($carriers as $carrier) {
                    if ((int) Configuration::get('FDM_WITH_CARTRULE')) {
                        $order_total_wt = $cart->getOrderTotal(
                            true,
                            Cart::BOTH_WITHOUT_SHIPPING,
                            $carrier['product_list'],
                            null,
                            false
                        );
                    } else {
                        $order_total_wt = $cart->getOrderTotal(
                            true,
                            Cart::ONLY_PRODUCTS_WITHOUT_SHIPPING,
                            $carrier['product_list']
                        );
                    }
                }
                if ($pricelimit > $order_total_wt) {
                    $value = (float) $pricelimit - $order_total_wt;
                    $text = 'Livraison gratuite : Pssst, plus que '. $value . ' € !';
                } else {
                    $value = 0;
                    $text = 'Frais de port offert!';    
                }
                $this->context->smarty->assign(
                  array(
                        'text' => $text,
                    )
                );
                return $this->display(__FILE__, 'page.tpl');
            }
            
        } 
    }

    public function getContent() {
        if(Tools::getIsset('save')){
            Configuration::updateValue('PS_GESTION_PORT',Tools::getValue('gestion'));
        }
        return $this->context->smarty->fetch($this->local_path.'/views/templates/admin/gestion.tpl');
    }
}