<?php
ini_set('display_errors', '0');
	if (!defined('_PS_VERSION_')) {
	    exit;
	}
	class commandetournee extends Module
	{
		private $url;
		public function __construct()
	    {
	        $this->name = 'commandetournee';
	        $this->tab = 'front_office_features';
	        $this->version = '1.0';
	        $this->author = 'Kiweerouge';
	        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => '1.7.99.99');
			$this->need_instance = 0;
			$this->bootstrap = true; 
	        parent::__construct();
			$this->displayName = $this->l('Commandetournee Module');
			$this->description = $this->l('Module commandetournee creation');
	    }
		public function install(){
			return parent::install() && $this->registerHook('backOfficeHeader');
		}
		public function uninstall(){
			return parent::uninstall();
		}
		public function getContent(){
			// si c'est une modif date + heure livraison
			if(isset($_POST['modif_date_heure_livraison']) && $_POST['modif_date_heure_livraison'] != ""){
	            $date_heure = $_POST['date_liv'].' '.$_POST['heure_liv'];
	            $helper = new HelperForm();
			    // Module, token and currentIndex
			    $helper->module = $this;
			    $helper->token = Tools::getAdminTokenLite('AdminModules');
	            $this->updateDateLivraison($_POST['id_cart'],date('Y-m-d h:i:s', strtotime($date_heure)));
	            Tools::redirect(_PS_BASE_URL_.'/admin-dev/'.AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'));
	        }
			if(Tools::getIsset('id_carrier')) {
			 	$type =	 $this->envoiSMS();	
			 	$this->context->smarty->assign(array(
					'orders' => $type,
				 ));
			 	return $this->context->smarty->fetch($this->local_path.'views/admin/message.tpl');
			} elseif (Tools::getIsset('action_modif_date_liv')) {
			 	$orders =	 $this->getAll();
			 	$this->context->smarty->assign(array(
					'orders' => $orders[0],
					'date_liv' => substr(date('d-m-Y H:i:s', $orders[0]['datetime']), 0,10),
					'heure_liv' => substr($this->arrondirHeure(substr(date('d-m-Y H:i:s', $orders[0]['datetime']),10)),0,5),
					'lien_retour' => _PS_BASE_URL_.'/admin-dev/'.AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
				 ));
			 	return $this->context->smarty->fetch($this->local_path.'views/admin/tournee.tpl');
			}else{
			 	$type = $this->typeSms(); 
			 	$this->context->smarty->assign(array(
						'register_order' => $type,
						'filtre_date_cmd' => $_POST['date'],
						'filtre_date_liv' => $_POST['date_liv']
				));
			}
			/*if(Tools::getValue('submit')) {
			 		$datep = $_POST['date'];
            		$date = date('Y-m-d',strtotime($datep));
            		$this->getDatepicker($date);
            		$type = $this->typeSms();
				 	 $this->context->smarty->assign(array(
							'register_order' => $type
					));	   
			}*/
			if(Tools::getValue('submit')){
			 	if (Tools::getValue('submit') == 'Filtrer') {
			 		$datep = $_POST['date'];
            		$date = date('Y-m-d',strtotime($datep));
            		$this->getDatepicker($date);
            		$type = $this->typeSms();
				 	$this->context->smarty->assign(array(
						'register_order' => $type
					));				 		
			 	} else {
			 		/* Créer fichier excel */
            		$infos = $this->typeSms();
            		$lignes[] = array('ID', 'Référence', 'Nom Client', 'Prénom Client', 'Adresse', 'Code Postal', 'Ville', 'Téléphone', 'Date Commande', 'Date Livraison');
            		foreach ($infos as $key => $value) {
            			$lignes[] = array($value['id_order'], $value['reference'], $value['lastname'], $value['firstname'], $value['address1'], $value['postcode'], $value['city'], $value['phone'], date('d/m/Y', strtotime($value['date_order'])), str_replace(' ', ' à ', date('d/m/Y H:i', $value['datetime'])));
            		}
					$delimiteur = ';';
					$fichier_csv = fopen('../modules/commandetournee/fiche_livraison.csv', 'w+');
					fprintf($fichier_csv, chr(0xEF).chr(0xBB).chr(0xBF));
					foreach($lignes as $ligne){
						fputcsv($fichier_csv, $ligne, $delimiteur);
					}
					fclose($fichier_csv);
					/* Download fichier excel */
				    $filepath = "../modules/commandetournee/fiche_livraison.csv";
				    if(file_exists($filepath)) {
				        header('Content-Description: File Transfer');
				        header('Content-Type: application/octet-stream');
				        header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
				        header('Expires: 0');
				        header('Cache-Control: must-revalidate');
				        header('Pragma: public');
				        header('Content-Length: ' . filesize($filepath));
				        flush();
				        readfile($filepath);
				        exit;
				    }
			 	}
			}
			return $this->display(__FILE__, "views/admin/admin.tpl");
		}
		// arrondi l'heure 
		function arrondirHeure($hour, $minutes = '30', $format = "h:i:00") {
		   $seconds = strtotime($hour);
		   $rounded = round($seconds / ($minutes * 60)) * ($minutes * 60);
		   return date($format, $rounded);
		}
		// mise à jours dete livraison vers la bdd
		public function updateDateLivraison($id_cart, $datetime){			
			$date_heure = $_POST['date_liv'].' '.$_POST['heure_liv'].':00 ';
			$date_tmp = strtotime($date_heure);
			$reqSql1 = 'UPDATE '._DB_PREFIX_.'deligume_sessions_shipping_tmp SET `datetime` = '.$date_tmp.' WHERE id_cart = '.$id_cart.'; ';
			$reqSql1.= 'UPDATE '._DB_PREFIX_.'order_carrier SET `date_add`= "'.date("Y-m-d H:i:s", strtotime($date_heure)).'" WHERE `id_order`= '.$_POST['id_order'];
            return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($reqSql1);
		}
		public function getDatepicker($date){
			$reqSql = "SELECT *, "._DB_PREFIX_."orders.date_add as date_order FROM "._DB_PREFIX_."orders 
				INNER JOIN " ._DB_PREFIX_."order_detail ON "._DB_PREFIX_."order_detail.id_order = "._DB_PREFIX_."orders.id_order
				INNER JOIN "._DB_PREFIX_."address ON dlps_orders.id_customer = "._DB_PREFIX_."address.id_customer 
				WHERE " ._DB_PREFIX_."orders.date_add like '%$date%'
				GROUP BY " ._DB_PREFIX_."orders.id_order";		
                $orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($reqSql);            
            	$val2 = array();
            	foreach($orders as $val){           		
            		$tab = $this->recupSms($val['id_carrier']);
            		$val['type'] = $tab;         		
            		$val2[]=$val;         		
            	}
            	$this->context->smarty->assign(array(			
						'register_order' => $val2
					));
            	return $val;       	    
		}
		public function getAll(){
			$reqSql = 'SELECT * , DATE_FORMAT('._DB_PREFIX_.'orders.date_add ,"%d-%m-%Y %H:%i:%s") as date_order, FROM_UNIXTIME(dsst.datetime ,"%d-%m-%Y %H:%i:%s") as date_liv 
                      FROM '._DB_PREFIX_.'orders 
                      INNER JOIN '._DB_PREFIX_.'order_detail ON '._DB_PREFIX_.'order_detail.id_order = '._DB_PREFIX_.'orders.id_order
                      INNER JOIN '._DB_PREFIX_.'address ON '._DB_PREFIX_.'orders.id_customer = '._DB_PREFIX_.'address.id_customer
                      INNER JOIN '._DB_PREFIX_.'deligume_sessions_shipping_tmp AS dsst ON '._DB_PREFIX_.'orders.id_cart = dsst.id_cart
                      WHERE 1 = 1 AND '._DB_PREFIX_.'orders.id_address_delivery = '._DB_PREFIX_.'address.id_address '; //Modification du 08/06/2018
                    if(isset($_POST['date']) && $_POST['date'] != '')
                        $reqSql .=' AND  '._DB_PREFIX_.'orders.date_add like "%'.date('Y-m-d', strtotime($_POST['date'])).'%"';
                    if(isset($_POST['date_liv']) && $_POST['date_liv'] != '')
                    	$reqSql .=' AND DATE_FORMAT(date_add( FROM_UNIXTIME(dsst.datetime) , INTERVAL 2 HOUR ),"%d-%m-%Y %H:%i:%s") like "%'.$_POST["date_liv"].'%"';
                    if(isset($_GET['action_modif_date_liv']) && $_GET['id_order'] != '')
                        $reqSql .=' AND  '._DB_PREFIX_.'orders.id_order  = "'.$_GET['id_order'].'"';
			$reqSql .=' GROUP BY '._DB_PREFIX_.'orders.id_order ORDER BY dsst.datetime';
			$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($reqSql);

            return $orders;
		}
		public function typeSms(){
			$t = $this->getAll();
			foreach ($t as $key => $val) {
				$orders = $this->recupSms($val);
				$t[$key]['type'] = $orders;
			}
			return $t;		
		}
		public function recupSms($val=null){
			$reqSql = "SELECT * FROM
				deligumesms_type_message AS dtm
				INNER JOIN deligumesms_carrier_message AS dcm ON dcm.code_type_msg = dtm.code_type_msg		
				WHERE dcm.id_carrier = ".$val['id_carrier'];
				$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($reqSql);
			return $orders;
		}
		public function envoiSMS(){
				$msg = $this->typeSms();	
				foreach ($msg as $key => $val) {					
					if($val['reference'] == Tools::getValue('ref')){
						$lastnameMsg = $val['firstname']." ".$val['lastname'];
						$referenceMsg = $val['reference'];
						$date_tmp = date('d-m-Y H:i:s', strtotime($val['date_liv']));
						$date = explode(' ', $date_tmp);						
						if($_GET['type_msg'] == 'CF'){

							$dateMsg = date('d-m-Y', strtotime($date[0]));
							$heureMsg = substr($date[1], 0,-3);
						}else{
							$dateMsg = $date[0];
							$heureMsg = substr($date[1], 0,-3);
						}

						$nouvelDateMsg = date("d-m-Y", strtotime($date[0] . ' + 3 days'));
						$nouvelleheureMsg = substr($date[1], 0,-3);
						for($i=0;$i<count($val['type']);$i++){
							if($val['type'][$i]['code_type_msg'] == Tools::getValue('type_msg')){
								$messageMsg = $val['type'][$i]['mess_default_content'];
								$messageMsg = str_replace("[Prenomduclient]",$lastnameMsg,$messageMsg);
								$messageMsg = str_replace("[Reference]",$referenceMsg,$messageMsg);
								$messageMsg = str_replace("[Date]",$dateMsg,$messageMsg);
								$messageMsg = str_replace("[Heure]",$heureMsg,$messageMsg);
								if(Tools::getValue('type_msg') == 'DC'){
									$messageMsg = str_replace("[NouvelleDate]",$nouvelDateMsg,$messageMsg);
									$messageMsg = str_replace("[NouvelleHeure]",$nouvelleheureMsg,$messageMsg);
								}
								$numLivreurMsg = $val['type'][$i]['mess_num_livreur'];
							}
						}
					return	$this->context->smarty->assign(array(
						'orders' => $val,
						'val'   => $val,
						'messageMsg' => $messageMsg,
						'idCarrier' => $val['id_carrier'],
						'numLivreur' => $numLivreurMsg,
						'phone' => $val['phone']
					 ));
					}					
				}	
		}
		public function replaceAll($find, $replace, $subject){
			$subject = preg_replace($find, $replace, $subject);
			return $subject;
		}
		public function hookBackOfficeHeader(){
			$this->context->controller->addCSS($this->_path.'views/css/'.$this->name.'.css');
			$this->context->controller->addjQuery();
			$this->context->controller->addJs($this->_path.'views/js/'.$this->name.'.js');
		}
	}