<?php
ini_set('display_errors', '0');
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once(dirname(__FILE__) . '/class/KisenderToolsSMS.php');
include_once(dirname(__FILE__) . '/controllers/admin/AdminDeligumeSMSAdmin.php');
use ApiOvh;
require_once(dirname(__FILE__) . '/class/ApiOvh.php');

class Deligumesms extends Module
{

    public function __construct()
    {
        $this->name = 'deligumesms';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Kiweerouge';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;
        
        parent::__construct();
        $aujourdhui = (new \DateTime())->format('Y-m-d');
        $this->displayName = $this->l('Deligume SMS : Vérification des commandes '.$aujourdhui);
        $this->description = $this->l('Système d\'envoie SMS par rapport aux commandes');
        $this->confirmUninstall = $this->l('Etes-vous sûr de vouloir désinstaller ?');
        $this->context->smarty->assign("templates_dir", _PS_MODULE_DIR_ . 'deligumesms/views/templates');
        if (!Configuration::get('DELIGUME_SMS_NAME')) {
            $this->warning = $this->l('No name provided');
        }
        $this->tabs = KisenderToolsSMS::getTabs();
        $this->addRessources();
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
        return parent::install() && $this->installHooks() && $this->installDB() && $this->installConfiguration() && $this->installTabs();
    }

    public function installConfiguration()
    {
        $configuration = array(
            "date_installation" => time(),
            "cle_api" => "",
            "expediteur" => "",
            "type" => "premium",
            "etat_annule" => false,
            "etat_annule_message" => "Votre commande a été annulée. Pour plus d'informations et effectuer une nouvelle commande, rendez-vous directement sur notre site internet.",
            "etat_en_cours" => false,
            "etat_en_cours_message" => "Votre commande est en cours de préparation. Pour plus d'informations et suivre votre commande, rendez-vous directement sur notre site internet.",
            "etat_expedie" => false,
            "etat_expedie_message" => "Votre commande vient d'être expédiée. Pour plus d'informations et suivre votre commande, rendez-vous directement sur notre site internet.",
            "etat_livre" => false,
            "etat_livre_message" => "Votre commande vous a été livrée. Pour effectuer une nouvelle commande, rendez-vous directement sur notre site internet.",
            "etat_rembourse" => false,
            "etat_rembourse_message" => "Votre commande vient de vous être remboursée. Pour plus d'informations et effectuer une nouvelle commande, rendez-vous directement sur notre site internet."
        );
        return Configuration::updateValue('DELIGUME_SMS_NAME', "Deligume SMS") && Configuration::updateValue('DELIGUME_SMS_SETTINGS', serialize($configuration));
    }

    public function installHooks()
    {
        return $this->registerHook('ActionOrderStatusUpdate');
    }

    public function installDB()
    {
        // table de configuration API
        $sSQL  =" DROP TABLE IF EXISTS deligumesms_configuration;";
        $sSQL .=" CREATE TABLE `deligumesms_configuration` ( `conf_dsms_id` INT (11) NOT NULL AUTO_INCREMENT, `conf_api_key` VARCHAR (255) NOT NULL, `conf_heure_envoie` TIMESTAMP NULL DEFAULT NULL, `conf_etat_service` SMALLINT (6) DEFAULT NULL, `conf_app_secret` VARCHAR (255) DEFAULT NULL, `conf_consumer_key` VARCHAR (255) DEFAULT NULL, `conf_end_point` VARCHAR (255) DEFAULT NULL, PRIMARY KEY (`conf_dsms_id`)) ENGINE = MyISAM AUTO_INCREMENT = 1 DEFAULT CHARSET = latin1;";
        $sSQL .=" DROP TABLE IF EXISTS deligumesms_carrier_message;";
        $sSQL .=" CREATE TABLE `deligumesms_carrier_message` ( `mess_dsms_id` INT (11) NOT NULL AUTO_INCREMENT, `mess_num_livreur` VARCHAR (255) NOT NULL, `id_carrier` INT (10) UNSIGNED NOT NULL, `mess_default_content` LONGTEXT NOT NULL, `code_type_msg` VARCHAR (5) NOT NULL, PRIMARY KEY (`mess_dsms_id`)) ENGINE = MyISAM AUTO_INCREMENT = 1 DEFAULT CHARSET = latin1;";
        $sSQL .=" DROP TABLE IF EXISTS deligumesms_type_message;";
        $sSQL .=" CREATE TABLE `deligumesms_type_message` ( `code_type_msg` VARCHAR (2) NOT NULL, `lib_type_msg` VARCHAR (255) NOT NULL, `description` VARCHAR (255) DEFAULT NULL ) ENGINE = MyISAM AUTO_INCREMENT = 1 DEFAULT CHARSET = latin1;";
        
        return Db::getInstance()->execute($sSQL);
        /*return Db::getInstance()->execute('') 
            && Db::getInstance()->execute('') 
            && Db::getInstance()->execute('') 
            && Db::getInstance()->execute('') 
            && Db::getInstance()->execute('');*/
    }

    private function installTabs()
    {
        $tab = new Tab();
        foreach (Language::getLanguages(false) as $lang) {
            $tab->name[$lang['id_lang']] = $this->l("Deligume SMS");
        }
        $tab->class_name = "AdminDeligumeEnvoyerSMS";
        $tab->id_parent = 0;
        $tab->module = $this->name;
        if ($tab->save()) {
            $id_parent = $tab->id;
            foreach ($this->tabs as $k => $v) {
                $tab = new Tab();
                foreach (Language::getLanguages(false) as $lang) {
                    $tab->name[$lang['id_lang']] = $this->l($v);
                }
                $tab->class_name = $k;
                $tab->id_parent = $id_parent;
                $tab->module = $this->name;
                if (!$tab->save()) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->uninstallConfiguration() && $this->uninstallTabs();
    }

    public function uninstallConfiguration()
    {
        return Configuration::deleteByName('DELIGUME_SMS_SETTINGS') && Configuration::deleteByName('DELIGUME_SMS_NAME');
    }

    private function uninstallTabs()
    {
        foreach ($this->tabs as $k => $v) {
            $this->uninstallTab($k);
        }
        $this->uninstallTab("AdminDeligumeEnvoyerSMS");
        return true;
    }

    private function uninstallTab($tabClass)
    {
        $idTab = Tab::getIdFromClassName($tabClass);
        if ($idTab) {
            $tab = new Tab($idTab);
            return $tab->delete();
        }
        return false;
    }

    public function hookActionOrderStatusUpdate($params)
    {
        if (isset($params['cart']) && !empty($params['cart'])) {
            $id_address = $params['cart']->id_address_delivery;
            if ($numero = KisenderToolsSMS::getNumero($id_address)) {
                $config = unserialize(Configuration::get('DELIGUME_SMS_SETTINGS'));
                if ($config['etat_annule'] && !empty($config['etat_annule_message']) && $params['newOrderStatus']->id == (int) Configuration::get('PS_OS_CANCELED')) {
                    KisenderToolsSMS::sendSMS($config['expediteur'], array($numero), $config['etat_annule_message'], $config['type']);
                } elseif ($config['etat_en_cours'] && !empty($config['etat_en_cours_message']) && $params['newOrderStatus']->id == (int) Configuration::get('PS_OS_PREPARATION')) {
                    KisenderToolsSMS::sendSMS($config['expediteur'], array($numero), $config['etat_en_cours_message'], $config['type']);
                } elseif ($config['etat_expedie'] && !empty($config['etat_expedie_message']) && $params['newOrderStatus']->id == (int) Configuration::get('PS_OS_SHIPPING')) {
                    KisenderToolsSMS::sendSMS($config['expediteur'], array($numero), $config['etat_expedie_message'], $config['type']);
                } elseif ($config['etat_livre'] && !empty($config['etat_livre_message']) && $params['newOrderStatus']->id == (int) Configuration::get('PS_OS_DELIVERED')) {
                    KisenderToolsSMS::sendSMS($config['expediteur'], array($numero), $config['etat_livre_message'], $config['type']);
                } elseif ($config['etat_rembourse'] && !empty($config['etat_rembourse_message']) && $params['newOrderStatus']->id == (int) Configuration::get('PS_OS_REFUND')) {
                    KisenderToolsSMS::sendSMS($config['expediteur'], array($numero), $config['etat_rembourse_message'], $config['type']);
                }
            }
        }
    }

    public function getListLivreurs(){
        // lister tous les livreurs
        $sql_livreur  = ' SELECT c.id_carrier, cl.delay, c.`name`, c.external_module_name, c.id_reference, c.id_tax_rules_group, c.url, c.active, c.deleted, c.shipping_handling, c.range_behavior, c.is_module, c.shipping_external, c.is_free, c.need_range, c.shipping_method, c.position, c.max_width, c.max_height, c.max_depth, c.max_weight, c.grade FROM `'._DB_PREFIX_.'carrier` AS c';
        $sql_livreur .= ' INNER JOIN '._DB_PREFIX_.'carrier_lang AS cl ON c.id_carrier = cl.id_carrier';  
        $sql_livreur .= ' WHERE c.deleted = 0 AND c.active = 1'; 
            
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_livreur);
    }

    public function getListTypeMsg(){
        // lister tous les livreurs
        $sql_type_msg  = ' SELECT tm.code_type_msg, tm.lib_type_msg, tm.description FROM `deligumesms_type_message` AS tm';
            
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_type_msg);
    }

    public function getInfoLivreur($criteres){
        
        $sql = "SELECT";

                if (isset($criteres['id_carrier']) && $criteres['code_type_msg'] != '0' ){
                    $sql.=" m.mess_dsms_id, m.mess_num_livreur, m.id_carrier, m.mess_default_content, m.code_type_msg";
                }else{
                    $sql.=" m.mess_dsms_id, m.mess_num_livreur";
                }

                $sql.=" FROM
                            deligumesms_carrier_message AS m
                        WHERE 1 = 1 ";

                if (isset($criteres['id_carrier']) && $criteres['id_carrier'] != ""){
                    $sql.=" AND m.id_carrier = '".$criteres['id_carrier']."'";
                }

                if (isset($criteres['code_type_msg']) && $criteres['code_type_msg'] != '0'){
                    $sql.=" AND m.code_type_msg = '".$criteres['code_type_msg']."'";
                }
              
        $carriers_info_msg = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        
        //if (isset($criteres['id_carrier']) && $criteres['code_type_msg'] != '0' ){
            die($carriers_info_msg[0]['mess_dsms_id'].'|'.$carriers_info_msg[0]['mess_num_livreur'].'|'.$carriers_info_msg[0]['mess_default_content']);
        /*}else{
            die($carriers_info_msg[0]['mess_num_livreur']);
        }*/
        

    }

    public function addRessources()
    {
        $this->context->controller->addCSS(($this->_path . '/views/css/styles.css'), 'all');
        $this->context->controller->addJquery();
        $this->context->controller->addJS(($this->_path . '/views/js/script.js'));
    }

    public function getContent()
    {
        if(isset($_POST['ajax_get_info_livreur']) && $_POST['ajax_get_info_livreur'] != ""){
            $this->getInfoLivreur($_POST);
        }

        $this->context->controller->addJS(($this->_path . '/views/js/configuration.js'));

        $sql_select = 'SELECT conf_dsms_id,conf_api_key, DATE_FORMAT(conf_heure_envoie, "%H:00:00") as conf_heure_envoie, conf_etat_service, conf_app_secret, conf_consumer_key, conf_end_point FROM deligumesms_configuration ';
        
        $registered_config = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_select);

        $AK = $registered_config[0]['conf_api_key'];
        $AS = $registered_config[0]['conf_app_secret'];
        $ep = $registered_config[0]['conf_end_point'];
        $CK = $registered_config[0]['conf_consumer_key'];

        $ApiOvh = new ApiOvh();

        $verif_api_validation = $ApiOvh->verifyApiIsValid($AK,$AS,$ep,$CK);
        $verif_sender_validation = "";
        // vérification si un expéditeur existe
        if(isset($_POST['ajax_get_info_sender']) && $_POST['ajax_get_info_sender'] != ""){
            $verif_sender_validation .= $ApiOvh->verifySenderIsValid($AK,$AS,$ep,$CK,$_POST['mess_num_livreur']);
        }

        $sql_param_txt = "";

        if(Tools::isSubmit('submitUpdateConfig'))
        {
           
            if(isset($_POST['conf_dsms_id']) && ($_POST['conf_dsms_id']) != ""){
                $sql_param_txt .= 'UPDATE `deligumesms_configuration` SET ';
                if(isset($_POST['conf_api_key']) && ($_POST['conf_api_key']) != "")
                    $sql_param_txt .= '`conf_api_key` = "'.$_POST['conf_api_key'].'" ,';
                if(isset($_POST['conf_heure_envoie']) && ($_POST['conf_heure_envoie']) != "")
                    $sql_param_txt .= '`conf_heure_envoie` = "'.$_POST['conf_heure_envoie'].'" ,';
                if(isset($_POST['conf_etat_service']) && ($_POST['conf_etat_service']) != "")
                    $sql_param_txt .= '`conf_etat_service` = "'.$_POST['conf_etat_service'].'" , ';
                if(isset($_POST['conf_app_secret']) && ($_POST['conf_app_secret']) != "")
                    $sql_param_txt .= '`conf_app_secret` = "'.$_POST['conf_app_secret'].'" ,';
                if(isset($_POST['conf_consumer_key']) && ($_POST['conf_consumer_key']) != "")
                    $sql_param_txt .= '`conf_consumer_key` = "'.$_POST['conf_consumer_key'].'", ';
                if(isset($_POST['conf_end_point']) && ($_POST['conf_end_point']) != "")
                    $sql_param_txt .= '`conf_end_point` = "'.$_POST['conf_end_point'].'", ';
                if(!isset($_POST['conf_etat_service']))
                    $sql_param_txt .= '`conf_etat_service` = "0"';
                else
                    $sql_param_txt .= '`conf_etat_service` = "'.$_POST['conf_etat_service'].'" ';

                $sql_param_txt .=' WHERE `conf_dsms_id` ='.$_POST['conf_dsms_id'];

                $sql_select = 'SELECT conf_dsms_id,conf_api_key, DATE_FORMAT(conf_heure_envoie, "%H:00:00") as conf_heure_envoie, conf_etat_service, conf_app_secret, conf_consumer_key, conf_end_point FROM `deligumesms_configuration';
                
                $registered_config = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_select);
            }else{
                $sql_param_txt = 'INSERT INTO `deligumesms_configuration` (`conf_api_key`,`conf_heure_envoie`,`conf_etat_service`,`conf_app_secret`,`conf_consumer_key`,`conf_end_point`) VALUES
                 ("'.$_POST['conf_api_key'].'","'.$_POST['conf_heure_envoie'].'","'.$_POST['conf_etat_service'].'","'.$_POST['conf_app_secret'].'","'.$_POST['conf_consumer_key'].'","'.$_POST['conf_end_point'].'")';
            }
            
            Db::getInstance()->execute($sql_param_txt);            
            
            Configuration::updateValue('MODULE_SYNCHRO', Tools::getValue('OurText'));
            Tools::redirect($_SERVER['HTTP_REFERER']);
            
        }


        $sql_msg = "";

        $sql_msg_config = 'SELECT m.mess_dsms_id, m.mess_num_livreur, m.id_carrier, m.mess_default_content FROM `deligumesms_carrier_message` AS m';
                
        $reg_msg_config = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_msg_config);

        if(Tools::isSubmit('submitUpdateTrans'))
        {
            if(isset($_POST['mess_dsms_id']) && ($_POST['mess_dsms_id']) != ""){
                $sql_msg .= 'UPDATE `deligumesms_carrier_message` SET ';
                if(isset($_POST['mess_dsms_id']) && ($_POST['mess_dsms_id']) != "")
                    $sql_msg .= '`mess_dsms_id` = "'.$_POST['mess_dsms_id'].'"';
                if(isset($_POST['id_carrier']) && ($_POST['id_carrier']) != "")
                    $sql_msg .= ', `id_carrier` = "'.$_POST['id_carrier'].'"';
                if(isset($_POST['mess_num_livreur']) && ($_POST['mess_num_livreur']) != "")
                    $sql_msg .= ', `mess_num_livreur` = "'.$_POST['mess_num_livreur'].'"';
                if(isset($_POST['mess_default_content']) && ($_POST['mess_default_content']) != "")
                    $sql_msg .= ', `mess_default_content` = "'.$_POST['mess_default_content'].'"';
                if(isset($_POST['code_type_msg']) && ($_POST['code_type_msg']) != "")
                    $sql_msg .= ', `code_type_msg` = "'.$_POST['code_type_msg'].'"';

                $sql_msg .=' WHERE `mess_dsms_id` ='.$_POST['mess_dsms_id'];
                
                $sql_msg_config = 'SELECT m.mess_dsms_id, m.mess_num_livreur, m.id_carrier, m.mess_default_content FROM `deligumesms_carrier_message` AS m';
                
                $reg_msg_config = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_msg_config);
            }else{
                $sql_msg = 'INSERT INTO `deligumesms_carrier_message` (`mess_dsms_id`,`mess_num_livreur`,`id_carrier`,`mess_default_content`,`code_type_msg`) VALUES
                 ("'.$_POST['mess_dsms_id'].'","'.$_POST['mess_num_livreur'].'","'.$_POST['id_carrier'].'","'.$_POST['mess_default_content'].'","'.$_POST['code_type_msg'].'")';
            }
            
            Db::getInstance()->execute($sql_msg);
            
            Tools::redirect($_SERVER['HTTP_REFERER']);
            
        }

        $return = array();
        $return['resultat'] = false;
        $return['erreur'] = "";
        if (isset($_REQUEST['action']) && $_REQUEST['action'] == "save_cle_api") {
            $ConfigurationController = new AdminDeligumeSMSAdminController();
            $ConfigurationController->saveCleAPI();
        }
        if (isset($_REQUEST['action']) && $_REQUEST['action'] == "save_configuration") {
            $ConfigurationController = new AdminDeligumeSMSAdminController();
            $return = $ConfigurationController->saveConfiguration();
        }        

        if (isset($_POST['ajax_id_carrier']) && $_POST['ajax_id_carrier'] != "") {
            
            $sql_msg_config = 'SELECT m.mess_dsms_id, m.mess_num_livreur, m.id_carrier, m.mess_default_content, m.code_type_msg FROM `deligumesms_carrier_message` AS m WHERE m.id_carrier = '.$_POST['ajax_id_carrier'];
            
            $reg_msg_config_ajax = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_msg_config);
            
            $this->context->smarty->assign("config_livreur_sms", $reg_msg_config_ajax[0]);

            $this->context->smarty->fetch('views/templates/admin/index.tpl');

        }else{
            $this->context->smarty->assign("config_livreur_sms", $reg_msg_config[0]);
        }

        $this->context->smarty->assign("config", $registered_config[0]);
        $this->context->smarty->assign("configSelectedEndPoint", $registered_config[0]['conf_end_point']);
        $this->context->smarty->assign("resMsgApiValidation", $verif_api_validation);
        $this->context->smarty->assign("resMsgSenderValidation", $verif_sender_validation);
        $this->context->smarty->assign("url_domain_base_ps", _PS_BASE_URL_.__PS_BASE_URI__);
        $this->context->smarty->assign("credits", KisenderToolsSMS::getCredits());
        $this->context->smarty->assign("retour", $return);
         
        $this->context->smarty->assign("transName", Carrier::getCarrierNameFromShopName());
        $this->context->smarty->assign("listLivreur", $this->getListLivreurs());  
        $this->context->smarty->assign("listTypeMsg", $this->getListTypeMsg());
        $token=Tools::getAdminToken('AdminDeligumeManageSMS'.(int)(Tab::getIdFromClassName('AdminDeligumeManageSMS')).(int)($cookie->id_employee));
        $this->context->smarty->assign("tokken_send_sms", $token);
        return $this->display(__FILE__, 'views/templates/admin/index.tpl');
    }

    public function hookFooter($params)
    {

        // Create a link with the good path
        $link = new Link;
        $parameters = array("action" => "load_ajax_livreur");
        $ajax_link = $link->getModuleLink('deligumesms','controller', $parameters);

        Media::addJsDef(array(
            "ajax_link" => $ajax_link
        ));

    }

}
