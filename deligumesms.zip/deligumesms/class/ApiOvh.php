<?php
include_once(dirname(__FILE__) . '/KisenderToolsSMS.php');
require __DIR__ . '/../vendor/autoload.php';
use \Ovh\Api;
class ApiOvh
{
    public static function getConfigSMSDeligume() {
        $sql_select = 'SELECT conf_dsms_id,conf_api_key, conf_heure_envoie, conf_etat_service, conf_app_secret, conf_consumer_key, conf_end_point FROM deligumesms_configuration ';
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_select);
    }

    public static function verifyApiIsValid($AK, $AS, $endpoint, $CK) {
        $resMsg = "";
        $ovh = new Api( $AK,$AS,$endpoint,$CK);
        /*$ovh = new Api( 'PpDbvuMeCYckz5dT',  // Application Key
                'uskaEUsmCk6yDAqr8YpOF3rPKhbNTkAI',  // Application Secret
                'ovh-ca',      // Endpoint of API OVH Europe (List of available endpoints)
                'dhrdHv8d01uD5vroaD56KfMvdOhDHhZa'); // Consumer Key*/

        $end_point_url = "";
        try{
            $result = $ovh->get('/service');   
        } catch (GuzzleHttp\Exception\ServerException $s) {
            $exp = explode('"', $s->getMessage());
            $resCodeErr = $s->getResponse()->getStatusCode();
            $host = $s->getRequest()->getUrl();
            $url_ep = explode('/', $host);
            $end_point_url = $url_ep[2];
            switch ($resCodeErr) {
            case '502':
                $resMsg.="Vous ne pouvez pas se connecter sur  le serveur du https://".$end_point_url;
                break;
            }
        } catch (GuzzleHttp\Exception\ClientException $e) {
            $exp = explode('"', $e->getMessage());
            $resCodeErr = $e->getResponse()->getStatusCode();
            switch ($resCodeErr) {
                case '403':
                    $resMsg.="Votre clé d'application et/ou consommer est invalide avec le serveur OVH: ".$endpoint;
                    break;
                case '400':
                    $resMsg.="La clé secret de votre application est invalide";
                    break;
                case '502':
                    $resMsg.="Vous ne pouvez pas se connecter sur le serveur du https://";
                    break;     
                default:
                    # NOT_CREDENTIAL
                    $resMsg.="Credential: Erreur de connexion ou application inexistante chez OVH";
                    break;
            }
        }     
        return $resMsg;
    }

    public static function suspendServiceSMS($AK, $AS, $CK) {
          $ovh = new Api( $AK,$AS,$CK); 
          $service_sms = $ovh->post('/service/17483820/suspend');
          return $service_sms ;
    }

    public static function reopenServiceSMS($AK, $AS, $CK) {
        $ovh = new Api( $AK,$AS,$CK); 
        $service_sms = $ovh->post('/service/17483820/reopen');
        return $service_sms;
    }

    public static function sendSMSDeligume($AK, $AS,$endpoint, $CK, $msg_array_content) {
        $ovh = new Api( $AK,$AS,$endpoint,$CK); 
        $resource_name = $ovh->get('/sms');
        $num_rec = KisenderToolsSMS::correctNumero($msg_array_content['phone_client']);
        $resMsg = "";
        $sender_name = "";
        if(isset($_POST['num_livreur']) && $_POST['num_livreur'] != '')
            $sender_name .= $_POST['num_livreur'];
        try{
            $post_sms = $ovh->post('/sms/'.$resource_name[0].'/jobs', array( // $msg_array_content
                'charset' => 'UTF-8', // The sms coding (type: sms.CharsetEnum)
                'class' => 'phoneDisplay', // The sms class (type: sms.ClassEnum)
                'coding' => '8bit', // The sms coding (type: sms.CodingEnum)
                'message' => utf8_encode($msg_array_content['mess_default_content']), //'SMS du '.(new \DateTime())->format('Y-m-d').' Test: Code wrapper (Mika - Kisender)', // Required: The sms message (type: string)
                'noStopClause' => false, // Do not display STOP clause in the message, this requires that this is not an advertising message (type: boolean)
                'priority' => 'high', // The priority of the message (type: sms.PriorityEnum)
                "receivers" => [ $num_rec ],
                'sender' => $sender_name, // The sender (type: string)
                'senderForResponse' => false, // Set the flag to send a special sms which can be reply by the receiver (smsResponse). (type: boolean)
                'validityPeriod' => '2880', // The maximum time -in minute(s)- before the message is dropped (type: long)
            ));
            header("Location: " . $_SERVER['HTTP_REFERER'] . '&msg=ok');
        } catch (GuzzleHttp\Exception\ClientException $e) {
            $exp = explode('"', $e->getMessage());
            $resCodeErr = $e->getResponse()->getStatusCode();
            switch ($resCodeErr) {
                case '403':
                    $resMsg.=" Forbidden 403";
                    break;   
                default:
                    # NOT_CREDENTIAL
                    $resMsg.=" ERROR UNKNOWN ";
                    break;
            }
            header("Location: ".$_SERVER['HTTP_REFERER'].'&msg=err');
        } 
    }

    // verification expéditeur isExist
    public static function verifySenderIsValid($AK, $AS, $endpoint, $CK, $expediteur) {
        $resMsg = "";
        $ovh = new Api( $AK,$AS,$endpoint,$CK);
        /*$ovh = new Api( 'PpDbvuMeCYckz5dT',  // Application Key
                'uskaEUsmCk6yDAqr8YpOF3rPKhbNTkAI',  // Application Secret
                'ovh-ca',      // Endpoint of API OVH Europe (List of available endpoints)
                'dhrdHv8d01uD5vroaD56KfMvdOhDHhZa'); // Consumer Key*/
        $resource_service_name = $ovh->get('/sms');
        $end_point_url = "";
        try {
            $result = $ovh->get('/sms/'.$resource_service_name.'/senders/'.$expediteur);  
        } catch (GuzzleHttp\Exception\ServerException $s) {
            $exp = explode('"', $s->getMessage());
            $resCodeErr = $s->getResponse()->getStatusCode();
            $host = $s->getRequest()->getUrl();
            $url_ep = explode('/', $host);
            $end_point_url = $url_ep[2];
            switch ($resCodeErr) {
                case '502':
                    $resMsg.="Vous ne pouvez pas se connecter sur  le serveur du https://".$end_point_url;
                    break;
                case '404':
                    $resMsg.= $expediteur." N'est pas un expéditeur OVH, si vous avez ajouter un expéditeur veuillez attendre le temps de validation";
                    break;
            }
        } catch (GuzzleHttp\Exception\ClientException $e) {
            $exp = explode('"', $e->getMessage());
            $resCodeErr = $e->getResponse()->getStatusCode();
            switch ($resCodeErr) {
                case '403':
                    $resMsg.="Votre clé d'application et/ou consommer est invalide avec le serveur OVH: ".$endpoint;
                    break;
                case '404':
                    $resMsg.= $expediteur." n'est pas un expéditeur OVH, si vous avez ajouter un expéditeur veuillez attendre le temps de validation";
                    break;
                case '400':
                    $resMsg.="La clé secret de votre application est invalide";
                    break;
                case '502':
                    $resMsg.="Vous ne pouvez pas se connecter sur le serveur du https://";
                    break;     
                default:
                    # NOT_CREDENTIAL
                    $resMsg.="Credential: Erreur de connexion ou application inexistante chez OVH";
                    break;
            }
        }     
        die($resMsg);
    }

}