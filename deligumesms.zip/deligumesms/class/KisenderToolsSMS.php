<?php
class KisenderToolsSMS
{
    public static function getTabs()
    {
        return array("AdminDeligumeSMSConfig" => "Configurer", "AdminDeligumeEnvoyerSMS" => "Envoyer des SMS");
    }
    public static function correctNumero($numero, $indicatif = '33')
    {
        $render = false;
        if (Tools::strlen($numero) == 49) {
            $numero = Tools::substr($numero, 0, -40);
        }
        $numero = str_replace('&#039;', "", $numero);
        $destinataire = preg_replace("/[^0-9]/", "", $numero);
        while (@$destinataire[0] == '0') {
            $destinataire = Tools::substr($destinataire, 1);
        }
        if (is_numeric($destinataire)) {
            $len = Tools::strlen($destinataire);
            if ($len == 9 || $len == 8) {
                $render = '+' . $indicatif . $destinataire;
            } elseif ($len == 10 or $len == 11 or $len == 12 or $len == 13) {
                $render = '+' . $destinataire;
            }
        }
        return $render;
    }
    public static function isMobile($numero, $indicatif = "33")
    {
        if (self::isInternational($numero)) {
            return true;
        }
        if ($indicatif !== "33") {
            return true;
        }
        return ($numero[3] == '6' or $numero[3] == '7');
    }
    public static function isInternational($numero)
    {
        return ($numero[1] !== '3' or $numero[2] !== '3');
    }
    public static function sendSMS($expediteur, $contacts = array(), $message = '', $type = 'premium')
    {
        $return = array();
        $return['resultat'] = false;
        $return['erreur'] = 0;
        $config = unserialize(Configuration::get('DELIGUME_SMS_SETTINGS'));
        if (isset($config['cle_api']) && !empty($config['cle_api'])) {
            $datas = array(
                'key' => $config['cle_api'],
                'destinataires' => $contacts,
                'type' => $type,
                'message' => $message,
                'expediteur' => Tools::substr($expediteur, 0, 11),
                'date' => ''
            );
            $ch = curl_init('http://www.spot-hit.fr/api/envoyer/sms');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datas, '', '&'));
            $reponse_json = curl_exec($ch);
            if (empty($reponse_json)) {
                return array('resultat' => 0, 'erreur' => 13);
            }
            curl_close($ch);
            $reponse_array = Tools::jsonDecode($reponse_json, true);
            if (!$reponse_array['resultat'] && is_array($reponse_array['erreurs'])) {
                $return['erreur'] = $reponse_array['erreurs'][0];
            } elseif ($reponse_array['resultat']) {
                $return['resultat'] = true;
            } else {
                $return['erreur'] = $reponse_array['erreurs'];
            }
        }
        return $return;
    }
    public static function getCredits()
    {
        $credits = array();
        $credits['post_paye'] = false;
        $credits['premium'] = 0;
        $credits['lowcost'] = 0;
        $credits['requete'] = false;
        $config = unserialize(Configuration::get('DELIGUME_SMS_SETTINGS'));
        if (isset($config['cle_api']) && !empty($config['cle_api'])) {
            $data = array(
                'key' => $config['cle_api']
            );
            $ch = curl_init('http://www.spot-hit.fr/api/credits');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data, '', '&'));
            $reponse_json = curl_exec($ch);
            curl_close($ch);
            if ($reponse_array = Tools::jsonDecode($reponse_json, true)) {
                if ($reponse_array['resultat']) {
                    $credits['post_paye'] = $reponse_array['post_paye'];
                    $credits['pre_paye'] = $reponse_array['pre_paye'];
                    $credits['euros'] = $reponse_array['euros'];
                    $credits['premium'] = $reponse_array['premium'];
                    $credits['lowcost'] = $reponse_array['lowcost'];
                    $credits['requete'] = true;
                }
            }
        }
        return $credits;
    }
    public static function getNumero($id_address)
    {
        $dataCustomer = Db::getInstance()->getRow('SELECT phone, phone_mobile from ' . _DB_PREFIX_ . 'address where id_address="' . $id_address . '"');
        $numero = false;
        $num_fix = $dataCustomer['phone'];
        $num_port = $dataCustomer['phone_mobile'];
        if ((($n = KisenderToolsSMS::correctNumero($num_port)) && KisenderToolsSMS::isMobile($n)) || (($n = KisenderToolsSMS::correctNumero($num_fix)) && KisenderToolsSMS::isMobile($n))) {
            $numero = $n;
        }
        return $numero;
    }
    public static function getContacts()
    {
        $adresses = Db::getInstance()->executeS('SELECT * FROM  ' . _DB_PREFIX_ . 'address');
        $contacts = array();
        foreach ($adresses as $adresse) {
            $prenom = $adresse['firstname'];
            $nom = $adresse['lastname'];
            if ((($n = KisenderToolsSMS::correctNumero($adresse['phone_mobile'])) && KisenderToolsSMS::isMobile($n)) || (($n = KisenderToolsSMS::correctNumero($adresse['phone'])) && KisenderToolsSMS::isMobile($n))) {
                $destinataires = $n;
                $contacts[] = array("prenom" => $prenom, "nom" => $nom, "numero" => $destinataires);
            }
        }
        return $contacts;
    }
}
