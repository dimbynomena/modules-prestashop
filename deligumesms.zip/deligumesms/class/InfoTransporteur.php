<?php

class InfoTransporteur
{

	public static function getConfigSMSDeligume()
    {

      return 'SELECT conf_dsms_id,conf_api_key, conf_heure_envoie, conf_etat_service, conf_app_secret, conf_consumer_key, conf_end_point FROM `deligumesms_configuration';
  
    }

	public static function getLivreurInfo($id_carrier)
    {
      return "SELECT * FROM deligumesms_carrier_message WHERE id_carrier =".$id_carrier;   
    }


}