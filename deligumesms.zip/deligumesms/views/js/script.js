/**
 * NOTICE OF LICENSE
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  @author    Xavier Lecoq
 *  @copyright 2015-2016 Inwave
 *  @license   GNU General Public License version 2
 */
$(document).ready(function () {

    $(document).on('change', 'select[name="type"]', function () {
        if ($(this).val() == "lowcost") {
            $('.expediteur').hide();
        } else {
            $('.expediteur').show();
        }
    });

    $(document).on('keyup', '.notification_message', function () {
        compteur($(this).attr('id'));
    });

    var xhr = [];
    function compteur(id_message) {
        if ($('#' + id_message)) {
            var supprimer = 0;
            if (xhr[id_message]) {
                xhr[id_message].abort();
            }
            xhr[id_message] = $.ajax({
                type: "POST",
                url: "http://www.spot-hit.fr/api/nombre_caracteres",
                dataType: 'json',
                data: {message: $('#' + id_message).val(), taille: 1, supprimer: "", add: ""}
            }).done(function (datas) {
                if (datas[2]) {
                    datas[0] = datas[0] + supprimer;
                }
                var replace = datas[0] > 160;
                setMessage(id_message, datas[1], replace);
                setCompteur(id_message, datas[0]);
            });
        }
    }

    function setCompteur(id_message, nbr) {
        if (nbr > 160) {
            nbr = 160;
        }
        $('#' + id_message + '_compteur .caracteres').text(nbr);
    }

    function setMessage(id_message, msg, replace) {
        if (replace) {
            var pos = $('#' + id_message).prop("selectionStart");
            $('#' + id_message).val(msg);
            $('#' + id_message).prop("selectionStart", pos);
            $('#' + id_message).prop("selectionEnd", pos);
        }
        return false;
    }

    compteur("etat_annule_message");
    compteur("etat_en_cours_message");
    compteur("etat_expedie_message");
    compteur("etat_livre_message");
    compteur("etat_rembourse_message");
    compteur("message");

});