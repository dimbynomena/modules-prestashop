<?php
include_once(dirname(__FILE__) . '/AdminDeligumeSMSAdmin.php');
require __DIR__ . '/../../class/ApiOvh.php';
class AdminDeligumeEnvoyerSMSController extends AdminDeligumeSMSAdminController
{
    public function __construct()
    {
        //$this->template = 'admin/envoyersms.tpl';
        $this->getMessageDetails($_POST);
        parent :: __construct();
    }
    public function setMedia()
    {
        parent::setMedia();
        $this->addCSS(_MODULE_DIR_ . 'deligumesms/views/css/dataTables.bootstrap.css');
        $this->addJS(_MODULE_DIR_ . 'deligumesms/views/js/jquery.dataTables.min.js');
        $this->addJS(_MODULE_DIR_ . 'deligumesms/views/js/dataTables.bootstrap.min.js');
        $this->addJS(_MODULE_DIR_ . 'deligumesms/views/js/envoyersms.js');
    }
    public function initContent()
    {
        print('<pre>');print_r($_GET);print('</pre>');
        parent::initContent();
        $return = array();
        $return['resultat'] = false;
        $return['erreur'] = "";
        $contacts = KisenderToolsSMS::getContacts();
        if (isset($_REQUEST['action']) && $_REQUEST['action'] == "envoyer_sms") {
            $return = $this->sendSMS();
        }
        $this->displayTemplate(array('retour' => $return, 'contacts' => $contacts));
    }
    public function getMessageDetails($details)
    {
        $sql_select = 'SELECT conf_dsms_id,conf_api_key, conf_heure_envoie, conf_etat_service, conf_app_secret, conf_consumer_key, conf_end_point FROM deligumesms_configuration ';
        $registered_config = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql_select);
        $ovh = new ApiOvh();
        return $ovh->sendSMSDeligume($registered_config[0]['conf_api_key'],$registered_config[0]['conf_app_secret'],$registered_config[0]['conf_end_point'],$registered_config[0]['conf_consumer_key'],$details);
    }
}