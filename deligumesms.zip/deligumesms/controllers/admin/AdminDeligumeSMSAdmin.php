<?php
include_once(dirname(__FILE__) . '/../../class/KisenderToolsSMS.php');
use ApiOvh;
class AdminDeligumeSMSAdminController extends AdminController
{
    public function __construct()
    {
        $new_api_sms = new ApiOvh();
        // $new_api_sms->sendSMSDeligume();
        $config = $new_api_sms->getConfigSMSDeligume();
        /*print('<pre>');print_r($config);print('</pre>');exit();*/
        parent :: __construct();
        $this->bootstrap = true;
    }
    public function createTemplate($tpl_name)
    {
        if (file_exists($this->getTemplatePath() . "/" . $tpl_name) && $this->viewAccess()) {
            return $this->context->smarty->createTemplate($this->getTemplatePath() . "/" . $tpl_name, $this->context->smarty);
        }
        return parent::createTemplate($tpl_name);
    }
    public function getTemplatePath()
    {
        return _PS_MODULE_DIR_ . 'deligumesms/views/templates';
    }
    public function displayTemplate($datas)
    {
        $this->context->smarty->assign(array_merge($datas, array("config" => unserialize(Configuration::get('DELIGUME_SMS_SETTINGS')), "credits" => KisenderToolsSMS::getCredits())));
    }
    public function initContent()
    {
        parent::initContent();
        if (isset($_REQUEST['action']) && $_REQUEST['action'] == "save_cle_api") {
            $this->saveCleAPI();
        }
    }
    public function setMedia()
    {
        parent::setMedia();
    }
    public function clearCache()
    {
        
    }
    public function getFields()
    {
        
    }
    public function saveCleAPI()
    {
        $config = unserialize(Configuration::get('DELIGUME_SMS_SETTINGS'));
        if (isset($_REQUEST['cle_api'])) {
            $config['cle_api'] = $_REQUEST['cle_api'];
        }
        return Configuration::updateValue('DELIGUME_SMS_SETTINGS', serialize($config));
    }
    public function saveConfiguration()
    {
        $return = array();
        $return['resultat'] = false;
        $return['erreur'] = "";
        $config = unserialize(Configuration::get('DELIGUME_SMS_SETTINGS'));
        if (isset($_REQUEST['cle_api'])) {
            $config['cle_api'] = trim($_REQUEST['cle_api']);
        }
        if (isset($_REQUEST['type']) && in_array($_REQUEST['type'], array("premium", "lowcost"))) {
            $config['type'] = $_REQUEST['type'];
        } else {
            $return['erreur'] = "type";
        }
        if (isset($_REQUEST['expediteur']) && $config['type'] == "premium") {
            $expediteur = trim($_REQUEST['expediteur']);
            if (Tools::strlen($expediteur) <= 11 && !is_numeric($expediteur)) {
                $config['expediteur'] = $expediteur;
            } else {
                $return['erreur'] = "expediteur";
            }
        }
        if (isset($_REQUEST['etat_annule'])) {
            $config['etat_annule'] = true;
        } else {
            $config['etat_annule'] = false;
        }
        if (isset($_REQUEST['etat_annule_message'])) {
            $config['etat_annule_message'] = trim($_REQUEST['etat_annule_message']);
        }
        if (isset($_REQUEST['etat_en_cours'])) {
            $config['etat_en_cours'] = true;
        } else {
            $config['etat_en_cours'] = false;
        }
        if (isset($_REQUEST['etat_en_cours_message'])) {
            $config['etat_en_cours_message'] = trim($_REQUEST['etat_en_cours_message']);
        }
        if (isset($_REQUEST['etat_expedie'])) {
            $config['etat_expedie'] = true;
        } else {
            $config['etat_expedie'] = false;
        }
        if (isset($_REQUEST['etat_expedie_message'])) {
            $config['etat_expedie_message'] = trim($_REQUEST['etat_expedie_message']);
        }
        if (isset($_REQUEST['etat_livre'])) {
            $config['etat_livre'] = true;
        } else {
            $config['etat_livre'] = false;
        }
        if (isset($_REQUEST['etat_livre_message'])) {
            $config['etat_livre_message'] = trim($_REQUEST['etat_livre_message']);
        }
        if (isset($_REQUEST['etat_rembourse'])) {
            $config['etat_rembourse'] = true;
        } else {
            $config['etat_rembourse'] = false;
        }
        if (isset($_REQUEST['etat_rembourse_message'])) {
            $config['etat_rembourse_message'] = trim($_REQUEST['etat_rembourse_message']);
        }
        if (empty($return['erreur'])) {
            if (!Configuration::updateValue('DELIGUME_SMS_SETTINGS', serialize($config))) {
                $return['erreur'] = "update_config";
            } else {
                $return['resultat'] = true;
            }
        }
        return $return;
    }
    public function sendSMS()
    {
        $expediteur = "";
        $destinataires = array();
        $message = "";
        $type = "premium";
        if (isset($_REQUEST['destinataires_autres']) && !empty($_REQUEST['destinataires_autres'])) {
            $destinataires_autres = explode("\n", $_REQUEST['destinataires_autres']);
            foreach ($destinataires_autres as $destinataire_autre) {
                if (($n = KisenderToolsSMS::correctNumero($destinataire_autre)) && !in_array($n, $destinataires)) {
                    $destinataires[] = $n;
                }
            }
        }
        if (isset($_REQUEST['destinataires']) && !empty($_REQUEST['destinataires'])) {
            $destinataires_liste = $_REQUEST['destinataires'];
            foreach ($destinataires_liste as $destinataire_liste) {
                if (($n = KisenderToolsSMS::correctNumero($destinataire_liste)) && !in_array($n, $destinataires)) {
                    $destinataires[] = $n;
                }
            }
        }
        if (isset($_REQUEST['message']) && !empty($_REQUEST['message'])) {
            $message = trim($_REQUEST['message']);
        }
        if (isset($_REQUEST['type']) && in_array($_REQUEST['type'], array("premium", "lowcost"))) {
            $type = $_REQUEST['type'];
        }
        return KisenderToolsSMS::sendSMS($expediteur, $destinataires, $message, $type);
    }
}
