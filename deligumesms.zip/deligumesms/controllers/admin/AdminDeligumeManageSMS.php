<?php
class AdminDeligumeManageSMSController extends AdminController
{
    public function __construct()
    {   
        $this->initContent();
        parent :: __construct();
    }
    public function initContent()
    {
        // __PS_BASE_URI__
        $url_config = $_SERVER['HTTP_HOST'].$_SERVER['BASE'].'/index.php?controller=AdminModules&configure=commandetournee&token=f64186338fb1948afa1b2258d7ae031c';
        header("Location: ".$url_config);
    }
}